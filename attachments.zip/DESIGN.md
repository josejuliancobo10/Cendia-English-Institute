---
name: Academic Clarity
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#424751'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#737783'
  outline-variant: '#c2c6d3'
  surface-tint: '#255dad'
  primary: '#00346f'
  on-primary: '#ffffff'
  primary-container: '#004a99'
  on-primary-container: '#9bbdff'
  inverse-primary: '#abc7ff'
  secondary: '#1f6771'
  on-secondary: '#ffffff'
  secondary-container: '#a8ebf5'
  on-secondary-container: '#246c75'
  tertiary: '#5f2200'
  on-tertiary: '#ffffff'
  tertiary-container: '#833301'
  on-tertiary-container: '#ffa77e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#abc7ff'
  on-primary-fixed: '#001b3f'
  on-primary-fixed-variant: '#00458f'
  secondary-fixed: '#abeef8'
  secondary-fixed-dim: '#8fd1db'
  on-secondary-fixed: '#001f23'
  on-secondary-fixed-variant: '#004f57'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb694'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e5e2e1'
  whatsapp-green: '#25D366'
  surface-gray: '#F8F9FA'
  border-subtle: '#E5E7EB'
typography:
  display-lg:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

The design system for Cendia English Institute is built on the pillars of **Academic Excellence** and **Professional Advancement**. It moves away from the previous multi-color palette toward a focused "Corporate Modern" aesthetic that resonates with adult learners and professionals in Quito looking for a trustworthy educational partner.

The style utilizes a **Corporate / Modern** approach:
- **Professionalism:** High-contrast layouts with structured grids that imply organization and reliability.
- **Modernity:** Subtle use of depth and generous whitespace to avoid the "cluttered" feel of traditional academic sites.
- **Conversion-Centric:** Clear visual hierarchy directing users toward enrollment and WhatsApp inquiries using high-visibility accent colors.
- **Welcoming:** Balancing the corporate blue with soft grays and rounded components to remain approachable for students of all levels.

## Colors

This color palette establishes a "Financial/Academic Blue" as the foundation of trust. 

- **Primary Blue (#004A99):** Used for headers, primary buttons, and critical brand moments. It conveys stability and authority.
- **Secondary Teal (#76B8C2):** Retained from the original brand to be used for decorative elements, secondary icons, and soft background washes.
- **Background:** Pure White (#FFFFFF) is the primary canvas to ensure maximum readability.
- **WhatsApp Green:** Reserved exclusively for the floating contact button and specific CTA banners. It must stand out as a distinct "action" color separate from the academic palette.
- **Grays:** Used strictly for borders and secondary text to maintain a clean, organized interface.

## Typography

The typography strategy pairs **Montserrat** for headings with **Inter** for body text. 

- **Headings (Montserrat):** Its geometric construction feels modern and architectural. Use bold weights for program titles and value propositions.
- **Body (Inter):** Chosen for its exceptional legibility in bilingual contexts. The neutral tone of Inter ensures that course descriptions and legal text are easy to digest.
- **Hierarchical Rules:** Use `display-lg` only for the primary hero section. All other page sections should lead with `headline-md`. Ensure a minimum contrast ratio of 4.5:1 for all body text against the background.

## Layout & Spacing

The system uses a **Fixed Grid** on desktop and a **Fluid Grid** on mobile devices.

- **Grid System:** A 12-column grid for desktop (1280px max-width). Components like "Course Cards" should span 4 columns (3 per row) or 6 columns (2 per row) depending on the level of detail.
- **Spacing Rhythm:** Based on an 8px scale. `stack-lg` (48px) should be used between major sections to provide the "generous whitespace" requested.
- **Mobile Adaptation:** At the 768px breakpoint, margins shrink to 16px and the 12-column grid collapses into a single-column stack for content blocks, while maintaining a 2-column grid for small feature icons.

## Elevation & Depth

To maintain a professional, academic feel, elevation is used sparingly to highlight interactive content.

- **Tonal Layers:** Use `surface-gray` (#F8F9FA) to differentiate between the main body content and section headers or footers.
- **Soft Shadows:** Apply subtle, highly diffused shadows to "Course Cards" and "Testimonial Cards." 
    - *Shadow Profile:* `0px 4px 20px rgba(0, 0, 0, 0.05)`.
- **Interactivity:** On hover, cards should lift slightly using a more pronounced shadow (`0px 8px 30px rgba(0, 0, 0, 0.08)`) to signal clickability.
- **Outlines:** Use 1px borders in `border-subtle` (#E5E7EB) for input fields and static containers where shadow depth is not required.

## Shapes

The design system uses a **Rounded (0.5rem)** logic to balance professional structure with a welcoming educational environment.

- **Buttons & Inputs:** Use the base `rounded` (8px) for a modern, standard feel.
- **Cards:** Use `rounded-lg` (16px) to soften the appearance of large content blocks like course details or pricing tables.
- **Chips/Badges:** Use `rounded-xl` (24px) for category labels (e.g., "English for Business," "Kids & Teens") to give them a distinct, friendlier appearance.
- **Icons:** Enclose icons in rounded-square containers with a light background tint to maintain a consistent visual weight.

## Components

- **Buttons:** 
    - *Primary:* Solid Corporate Blue with white text. High-contrast, 8px radius.
    - *Secondary:* Ghost style with Corporate Blue border and text.
    - *WhatsApp CTA:* Solid #25D366 with a white icon and text; always includes a subtle "pulse" animation for the floating mobile version.
- **Cards:** White background, 1px subtle border, and 16px corner radius. Used for "Our Courses" and "Teacher Profiles."
- **Input Fields:** 12px vertical padding, subtle gray borders. Focus state must use a 2px Corporate Blue outline.
- **Chips:** Small tags used to denote "Level A1," "B2," etc. Use a light blue background with the Primary Blue text for high legibility.
- **Lists:** Use custom "Checkmark" icons in the Secondary Teal color instead of standard bullets to reinforce the "success/achievement" narrative.
- **Testimonials:** Quote cards with the student's photo in a circular frame, emphasizing social proof for Ecuadorian students and professionals.