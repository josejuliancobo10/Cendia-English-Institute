Saltar al contenido

  * [CENDIA FOR TEACHERS](http://cendia.jimdo.com)
  * [CONTACTOS](https://cendia.edu.ec/contactos/)
  * INGRESO AL SISTEMA



[ ](https://cendia.edu.ec/)

[ ](https://cendia.edu.ec/ "Cendia")

Menú

  * [Inicio](http://cendia.edu.ec)
  * Nuestros Servicios
    * [Cursos Regulares de Inglés](https://cendia.edu.ec/adultos/)
    * [Cursos de Conversación](https://cendia.edu.ec/adolescentes/)
    * [Nivelación para estudiantes](https://cendia.edu.ec/nivelacion-para-estudiantes/)
    * [Inglés de negocios](https://cendia.edu.ec/ingles-de-negocios/)
    * [In-house Classes](https://cendia.edu.ec/in-house-classes/)
    * [Traducciones](https://cendia.edu.ec/traducciones/)
    * Cursos para empresas
  * Tests
    * [Test en linea](https://cendia.edu.ec/test-el-linea/)
    * [Exámenes de ubicación](https://cendia.edu.ec/examenes-de-ubicacion/)
  * Preparación Exámenes
    * [FCE](https://cendia.edu.ec/fce/)
    * [ELTS](https://cendia.edu.ec/elts/)
    * [KET](https://cendia.edu.ec/ket/)
    * [PET](https://cendia.edu.ec/pet/)
    * [TOEFL](https://cendia.edu.ec/toefl/)
  * [Horarios](https://cendia.edu.ec/inicio-2/horarios/)
  *   * 


[ ](https://cendia.edu.ec/ "Cendia")

  * [Inicio](http://cendia.edu.ec)
  * Nuestros Servicios
    * [Cursos Regulares de Inglés](https://cendia.edu.ec/adultos/)
    * [Cursos de Conversación](https://cendia.edu.ec/adolescentes/)
    * [Nivelación para estudiantes](https://cendia.edu.ec/nivelacion-para-estudiantes/)
    * [Inglés de negocios](https://cendia.edu.ec/ingles-de-negocios/)
    * [In-house Classes](https://cendia.edu.ec/in-house-classes/)
    * [Traducciones](https://cendia.edu.ec/traducciones/)
    * Cursos para empresas
  * Tests
    * [Test en linea](https://cendia.edu.ec/test-el-linea/)
    * [Exámenes de ubicación](https://cendia.edu.ec/examenes-de-ubicacion/)
  * Preparación Exámenes
    * [FCE](https://cendia.edu.ec/fce/)
    * [ELTS](https://cendia.edu.ec/elts/)
    * [KET](https://cendia.edu.ec/ket/)
    * [PET](https://cendia.edu.ec/pet/)
    * [TOEFL](https://cendia.edu.ec/toefl/)
  * [Horarios](https://cendia.edu.ec/inicio-2/horarios/)
  *   * 


## [La mejor experiencia en Inglés](https://cendia.edu.ec/metodo/)

Un método con el que garantizamos tu aprendizaje.

[Conoce más... ](https://cendia.edu.ec/metodo/)

## [Un horario para cada necesidad](https://cendia.edu.ec/inicio-2/horarios/)

Tenemos el horario perfecto para ti!

[Conoce más... ](https://cendia.edu.ec/inicio-2/horarios/)

## Certifica tu B2 con Cambridge

Haz click aquí

AVISO IMPORTANTE

#### **Inicio de clases (Lunes a Viernes) 4 de junio 2026 / Inicio de clases (Sábados) 6 de junio 2026**

[Calendario actividades](https://cendia.edu.ec/events/)

## Curso regulares de Inglés

___________________

Sabemos cómo aprende una persona, por eso nuestro curso es efectivo.

[Conoce más...](https://cendia.edu.ec/adultos/)

## Cursos de Conversación

___________________

Clases muy divertidas,  practica la pronunciación correcta del idioma Inglés…

[Conoce más...](https://cendia.edu.ec/adolescentes/)

## Exámenes internaciones

___________________

Prepárate correctamente para los exámenes internacionales más requeridos…

[Conoce más...](https://cendia.edu.ec/fce/)

## Test en línea 

___________________

¿Sabes cuál es tu nivel de inglés?, ingresa a  nuestro test online y descúbrelo en este momento.

[Conoce más...](https://cendia.edu.ec/test-el-linea/)

# Un entorno natural de aprendizaje.

Todos nuestros cursos son enteramente en inglés desde el día uno, de esa manera nos aseguramos de que tu aprendizaje sea efectivo y satisfactorio.

[Más información...]()

NUESTRO CENTRO DE ESTUDIO

#### **La Mariscal – Quito Norte**

[](https://cendia.edu.ec/wp-content/uploads/2015/10/cendia6.jpg "La Mariscal – Quito Norte")

¡Déjanos tus datos!

Nombre

Apellido

Dirección de correo electrónico

Celular

¿Dónde quieres estudiar? ¿Dónde quieres estudiar?MariscalCalderonOnline

En qué estás interesad@? En qué estás interesad@?Curso de inglésExamen de inglés AptisCurso personalizadoCurso para empresasCurso de prepara

Mensaje

Submit

LO QUE DICEN NUESTROS ESTUDIANTES

Cendia ha sido el único instituto que lleno mis expectativas, y gracias a la calidad de sus servicios al fin pude lograr uno de mis más grades sueños, el de aprender inglés, estoy muy agradecida.

Paulina García

# **El compromiso de Cendia:**

Al final de todo el programa, los alumnos estarán en la capacidad de **hablar, entender, escribir y comunicarse integralmente en el idioma de inglés**.  
**Aprendizaje de calidad, comprometido, serio y profesional.**

info@cendia.edu.ec

#### 

#### 

#### 

#### La Mariscal – Quito Norte

**Dirección** : Baquerizo Moreno E8-26 y Almagro

**Teléfono** : 022-528-551

Whatsapp: +593 99 872 0970

__________________________________________________________

#### 

 

  * [Follow](https://www.facebook.com/cendiaenglish "Follow on Facebook")
  * [Follow](https://twitter.com/cendiaenglish "Follow on X")
  * [Follow](https://www.instagram.com/Cendia/ "Follow on Instagram")



  * [¿Cómo matricularse?](https://cendia.edu.ec/que-necesitas-para-matricularte/)
  * [Acerca de nosotros](https://cendia.edu.ec/sobre-nosotros/)
  * [Cursos](https://cendia.edu.ec/examenes-de-ubicacion/)
  * [Examen de ubicación](https://cendia.edu.ec/examenes-de-ubicacion/)
  * [Trabaje con nosotros](https://cendia.edu.ec/trabaje-con-nosotros/)
  * [Formulario de contacto](https://cendia.edu.ec/contactos/)
  * [Servicio para empresas](https://cendia.edu.ec/in-house-classes/)



Cendia English Institute 2026 © Copyright Desarrollado por Cendia 

  * [¿Requisitos para matricularte?](https://cendia.edu.ec/que-necesitas-para-matricularte/)
  * [Sobre nosotros](https://cendia.edu.ec/sobre-nosotros/)
  * [Método](https://cendia.edu.ec/metodo/)
  * [Calendario de actividades](http://cendia.edu.ec/events/)
  * [Trabaje con nosotros](https://cendia.edu.ec/trabaje-con-nosotros/)